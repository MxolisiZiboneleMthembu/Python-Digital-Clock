#import tkinter to create GUI elements

from tkinter import *
from time import *

#Creates labels
def update():
    current_time_string = strftime("%I:%M:%S %p")
    current_time_label.config(text=current_time_string)

    current_day_string = strftime("%A")
    current_day_label.config(text=current_day_string)

    current_date_string = strftime("%B %d, %Y")
    current_date_label.config(text=current_date_string)

    window.after(1000,update)

#create a blank window to display time
window = Tk()

#Display labels on screen
current_day_label = Label(window,font=("Calibri",60,"bold"),fg="#9876ab")
current_day_label.pack()

current_time_label = Label(window,font=("Calibri",40,"bold"),fg="#9876ab",bg="white")
current_time_label.pack()

current_date_label = Label(window,font=("Ink Free",30))
current_date_label.pack()

update()

window.mainloop()
